
import { renderHook, act } from '@testing-library/react-hooks';
import { ThemeProvider, useTheme } from '../src/context/ThemeContext';

describe('ThemeContext', () => {
  it('toggles theme correctly', () => {
    const { result } = renderHook(() => useTheme(), { wrapper: ThemeProvider });
    expect(result.current.theme).toBe('light');
    act(() => result.current.toggleTheme());
    expect(result.current.theme).toBe('dark');
  });
});

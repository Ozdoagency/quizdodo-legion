
import { render, screen, fireEvent } from '@testing-library/react';
import { RatingInput } from '../src/components/RatingInput';

describe('RatingInput', () => {
  it('renders correct number of stars', () => {
    render(<RatingInput value={3} onChange={jest.fn()} max={5} />);
    const stars = screen.getAllByRole('radio');
    expect(stars).toHaveLength(5);
  });

  it('handles click correctly', () => {
    const handleChange = jest.fn();
    render(<RatingInput value={0} onChange={handleChange} max={5} />);
    const star = screen.getAllByRole('radio')[2];
    fireEvent.click(star);
    expect(handleChange).toHaveBeenCalledWith(3);
  });
});

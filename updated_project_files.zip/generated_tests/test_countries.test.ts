
import { validatePhoneNumber } from '../src/data/countries';

describe('validatePhoneNumber', () => {
  it('returns true for valid phone numbers', () => {
    expect(validatePhoneNumber('12345678', '+380')).toBe(true);
  });

  it('returns false for invalid phone numbers', () => {
    expect(validatePhoneNumber('123', '+380')).toBe(false);
  });

  it('returns false for unsupported country codes', () => {
    expect(validatePhoneNumber('12345678', '+999')).toBe(false);
  });
});

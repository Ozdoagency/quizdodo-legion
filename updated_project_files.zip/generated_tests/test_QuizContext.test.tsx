
import { renderHook, act } from '@testing-library/react-hooks';
import { QuizProvider, useQuizContext } from '../src/context/QuizContext';

describe('QuizContext', () => {
  it('updates step correctly', () => {
    const { result } = renderHook(() => useQuizContext(), { wrapper: QuizProvider });
    act(() => result.current.setCurrentStep(2));
    expect(result.current.currentStep).toBe(2);
  });
});

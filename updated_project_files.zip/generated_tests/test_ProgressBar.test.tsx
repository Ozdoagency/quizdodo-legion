
import { render, screen } from '@testing-library/react';
import { ProgressBar } from '../src/components/ProgressBar';

describe('ProgressBar', () => {
  it('renders correctly with given steps', () => {
    render(<ProgressBar currentStep={2} totalSteps={5} />);
    const progressBar = screen.getByRole('progressbar');
    expect(progressBar).toHaveStyle('width: 60%'); // (2 + 1) / 5 * 100
  });

  it('handles zero total steps gracefully', () => {
    render(<ProgressBar currentStep={0} totalSteps={0} />);
    const progressBar = screen.getByRole('progressbar');
    expect(progressBar).toHaveStyle('width: 100%'); // Fallback to 1 step minimum
  });
});

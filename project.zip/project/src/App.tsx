import { useState } from 'react';
import Quiz from './components/Quiz';
import { QuizSidebar } from './components/QuizSidebar';
import { LanguageSelector } from './components/LanguageSelector';
import { ThemeToggle } from './components/ThemeToggle';
import { ArrowRight, Gift, Shield, Clock, Sparkles } from 'lucide-react';
import { useLanguage } from './context/LanguageContext';
import { translations } from './translations';

export default function App() {
  const [isQuizStarted, setIsQuizStarted] = useState(false);
  const { language } = useLanguage();
  const t = translations[language];

  if (isQuizStarted) {
    return (
      <div className="min-h-screen bolt-background p-4 relative grid-background">
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-[280px,1fr] gap-4 lg:gap-6">
          <div className="hidden lg:block">
            <QuizSidebar />
          </div>
          <Quiz />
        </div>
        
        <div className="lg:hidden fixed bottom-0 left-0 right-0 text-center py-3 bg-background/80 backdrop-blur-sm border-t border-white/10">
          <span className="text-primary font-semibold">{t.header.madeIn} </span>
          <span className="font-bold text-foreground">QuizDo</span>
        </div>
        
        <div className="lg:hidden h-16"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bolt-background relative overflow-hidden grid-background">
      {/* Header */}
      <div className="w-full border-b border-white/10 bg-background/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="text-center">
            <span className="text-primary font-semibold">{t.header.madeIn} </span>
            <span className="font-bold text-foreground">QuizDo</span>
          </div>
          <div className="flex items-center gap-4">
            <LanguageSelector />
            <ThemeToggle />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-12 md:py-16">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-sm rounded-full text-primary text-sm font-medium mb-6 border border-white/10">
            <Sparkles className="w-4 h-4" />
            {t.hero.specialOffer}
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
            {t.hero.title}
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            {t.hero.subtitle}
          </p>

          <button
            onClick={() => setIsQuizStarted(true)}
            className="bolt-button group"
          >
            <span className="relative z-10 flex items-center gap-2 text-lg">
              {t.cta}
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </span>
          </button>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <div className="bolt-card group">
            <div className="bolt-glow" />
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-primary/10 backdrop-blur-2xl">
                <Clock className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground text-lg mb-2">
                  {t.features.quickCalculation.title}
                </h3>
                <p className="text-muted-foreground mb-4">
                  {t.features.quickCalculation.description}
                </p>
                <ul className="space-y-2">
                  {t.features.quickCalculation.benefits.map((benefit, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-4 h-4 rounded-full bg-primary/10 flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-primary" />
                      </div>
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="bolt-card group">
            <div className="bolt-glow" />
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-primary/10 backdrop-blur-2xl">
                <Gift className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground text-lg mb-2">
                  {t.features.yourBonuses.title}
                </h3>
                <p className="text-muted-foreground mb-4">
                  {t.features.yourBonuses.description}
                </p>
                <ul className="space-y-2">
                  {t.features.yourBonuses.benefits.map((benefit, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-4 h-4 rounded-full bg-primary/10 flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-primary" />
                      </div>
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-sm rounded-lg border border-white/10">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">
              {t.security}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
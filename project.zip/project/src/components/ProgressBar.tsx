import type { FC } from 'react';

type Props = {
  currentStep: number;
  totalSteps: number;
};

export const ProgressBar: FC<Props> = ({ currentStep, totalSteps }) => {
  const progressWidth = `${((currentStep + 1) / totalSteps) * 100}%`;

  return (
    <div className="w-full h-2 bg-secondary rounded-full mb-8 overflow-hidden relative">
      <div
        className="h-full bg-gradient-to-r from-primary to-primary/80 progress-bar rounded-full relative"
        style={{ width: progressWidth }}
      >
        <div 
          className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.2)_50%,transparent_75%)] bg-[length:20px_20px] animate-barberpole" 
        />
      </div>
    </div>
  );
};